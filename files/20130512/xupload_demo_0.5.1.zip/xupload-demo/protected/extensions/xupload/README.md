# XUpload extension for Yii Framework

## Yii extension page
[Extension page](http://www.yiiframework.com/extension/xupload/)

## Demo
[jQuery file upload](http://blueimp.github.com/jQuery-File-Upload/ "jQuery File Upload") extension for Yii, 
allows your users to easily upload files to the server.


* [XUpload Workflow example](http://www.yiiframework.com/wiki/348/xupload-workflow/)
* [Additional form data with XUpload](http://www.yiiframework.com/wiki/395/additional-form-data-with-xupload/)
